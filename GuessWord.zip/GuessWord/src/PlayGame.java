import java.util.Arrays;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import java.awt.Graphics;
import javax.swing.JPanel;
import java.security.SecureRandom;


public class PlayGame {

	 public static void main (String[]args){	 
	 Word myword;
	 boolean play=true; 	
	 
	 while (play){
		 GetWord GetW=new GetWord();
		 myword=new Word(GetW.getWord());
		 String s="-";
			int g=0;
			for (int i=0;i<myword.getLength()-1;i++){ s = s.concat("-");}		
			JFrame f = new JFrame();
			String Nmessage= String.format("Your word is %s %n please enter your letter",s);			
			String Ninput=JOptionPane.showInputDialog(f,Nmessage);
			
			while(!GetW.getWord().equals(s)) {			
				int[] temp=myword.containsLet(Ninput);
				if (temp==null){ 
					Nmessage= String.format("You already tried this letter%n the word is %s %n please choose another letter",s);					
					Ninput=JOptionPane.showInputDialog(f,Nmessage);					
								}				
					else {					
					s=myword.strUpdate(s, temp, Ninput);
					if(GetW.getWord().equals(s)){break;}
					Nmessage= String.format("Your word is %s %n please enter your letter",s);			
					Ninput=JOptionPane.showInputDialog(f,Nmessage);
					
								}
				g++;                   		 }
			
			if (GetW.getWord().equals(s)){
				String mes= String.format("Great!%n The word is%n %s %n You did it within %d tries",GetW.getWord(),g);	
				JOptionPane.showMessageDialog(null,mes);
				int result = JOptionPane.showConfirmDialog(null,"Would you like to play again?",null, JOptionPane.YES_NO_OPTION);
                if (result==JOptionPane.YES_OPTION){play=true;}else { play=false;}
										}		 
	 }	 
	 }
}
