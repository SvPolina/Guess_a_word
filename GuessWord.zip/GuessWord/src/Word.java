import java.io.*;
import java.lang.*;
import java.util.Arrays;

/*
 *This class contains all the operations performed on the string 
 *representing the word the user is trying to guess.
 */
public class Word {
	
	
	private String word;
	public int Length;
	private String check;
	

	public Word(String input){
	this.word=input;
	this.Length=word.length();
	this.check="";
	}
	
	public int getLength()
  	{
	  return Length;
  	}
		
	
//Checks if the word contains the letter typed by the user 
	public int[] containsLet(String Let){
		if (checkRepetition(Let)==true){ return null; }
		else{
			setCheck(Let);
		int[] b = new int[1];		
		b[0]=-1;		
		int index=0;
		int i=0;
		
		if(word.indexOf(Let)==0){b[i]=0; i++;b = Arrays.copyOf(b, b.length+1);}
		
		while(index!=-1)			
		{	
			index=word.indexOf(Let,index+1);
			if (index!=-1){b[i]=index;b = Arrays.copyOf(b, b.length+1);}	
			i++;
		}
		b = Arrays.copyOf(b, b.length-1);
		return b;}
	}	
	
//Replaces the "-" sign at the appropriate place in the string representing the word,
//with the letter the user guessed 	
	
	public String strUpdate(String toUpdate, int[] arr, String Let){
		   StringBuilder str=new StringBuilder(toUpdate);
		   char c=Let.charAt(0);
	       for (int i=0; i<arr.length; i++)  {
	    	   str.setCharAt(arr[i], c);	 }
	      String s=str.toString(); 
	    return s;   	    
	} 
	
//Checks if the letter guessed by the user appears in the word more than 1 time	
	private boolean checkRepetition(String Let){
	if (check.indexOf(Let.charAt(0))!=-1){return true;	}		
	else return false;	
												}
	
	public void setCheck(String Let){		
		check=check.concat(Let);	}
	
	public String getCheck(){return check;}
	
}
