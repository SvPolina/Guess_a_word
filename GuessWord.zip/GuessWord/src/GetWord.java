import java.security.SecureRandom;


/*
 The class contains an array of words and randomly chooses one word
*/
public class GetWord {	
	public String[] Voc={"imagine","ducks","receptive","melodic","sudden","glow","base","milk","assuming"};		
	public static final SecureRandom randomNumbers = new SecureRandom();
	public int num=randomNumbers.nextInt(Voc.length);		
   	
	public String getWord()
	{		 
		return Voc[num];
	}

}
